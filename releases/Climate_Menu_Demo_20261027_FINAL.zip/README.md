# Climate Menu

Climate Menu is an R/Shiny application for selecting a study area, climate exposure, time periods and climate-model settings, and running the corresponding climate analysis through a reproducible targets backend.

**Important:** This is a demonstration/research build. Not every possible combination of options has been fully validated.

---

## 1. First-time setup

Climate Menu requires:

- R
- RStudio (recommended)
- an internet connection for remotely accessed climate and boundary data

R and RStudio only need to be installed once.

### Install the required R packages

Open RStudio and paste the following into the Console:

```r
packages <- c(
  "shiny", "targets", "tarchetypes", "terra", "sf", "ncdf4",
  "dplyr", "tidyr", "stringr", "purrr", "ggplot2", "lubridate",
  "jsonlite", "httr", "digest"
)

missing <- setdiff(
  packages,
  rownames(installed.packages())
)

if (length(missing)) {
  install.packages(missing)
}
```

This installs only packages that are not already installed.

The `.R` files supplied with Climate Menu are part of Climate Menu itself. They do **not** need to be installed separately.

---

## 2. Download and extract Climate Menu

1. Download the Climate Menu ZIP file.
2. Save it to a convenient location.
3. Extract/unzip the complete ZIP file.
4. Open the extracted top-level Climate Menu folder.

**Do not run Climate Menu from inside the ZIP file.**

The extracted folder should contain items including:

```text
RUN_CLIMATE_MENU.R
README.md
app_20261026_v06.R
Climate_Menu_targets_20261026_v06.R
config/
functions/
runtime/
```

---

## 3. Set the working directory in RStudio

In RStudio choose:

**Session > Set Working Directory > Choose Directory...**

Select the **top-level extracted Climate Menu folder** - the folder that directly contains `RUN_CLIMATE_MENU.R`.

Do not select `config`, `functions`, `runtime` or another subfolder.

To check that RStudio is pointing to the correct folder, run:

```r
file.exists("RUN_CLIMATE_MENU.R")
```

The result should be:

```text
[1] TRUE
```

---

## 4. Start Climate Menu

In the RStudio Console run:

```r
source("RUN_CLIMATE_MENU.R")
```

The launcher checks the required R packages and then starts the Climate Menu Shiny application.

If a required package is missing, Climate Menu will list the missing package or packages and provide an installation command.

---

## 5. Run an analysis

Use the Climate Menu interface to select the required:

1. research question and climate metric;
2. study area;
3. climate-data product;
4. historical and/or future periods;
5. emissions scenario and climate-model settings;
6. analysis options.

Then:

1. review the selections;
2. click **Build analysis request**;
3. inspect the analysis request if required;
4. click **Run analysis**.

Some analyses retrieve climate-model data remotely and therefore require an internet connection and may take time to complete.

Selecting a small ABS study area does not increase the resolution of the climate data. Climate values retain the underlying climate-model grid resolution.

---

## 6. Close Climate Menu

To close Climate Menu cleanly:

1. Close the Climate Menu browser tab or window.
2. Return to RStudio.
3. If Climate Menu is still running, click the red **Stop** button in RStudio or press **Esc**.
4. Wait until the normal `>` prompt returns in the R Console.
5. You can then close RStudio normally if you have finished working.

You should not normally need to use Windows Task Manager or forcibly terminate R.

---

## 7. Starting Climate Menu next time

After the first-time setup, you normally only need to:

1. open RStudio;
2. set the working directory to the extracted Climate Menu folder;
3. run:

```r
source("RUN_CLIMATE_MENU.R")
```

You do **not** need to reinstall the R packages every time.

---

## 8. Troubleshooting

### Climate Menu reports a missing R package

Install the package reported by Climate Menu. For example:

```r
install.packages("PACKAGE_NAME")
```

Then run the Climate Menu launcher again.

### R cannot find `RUN_CLIMATE_MENU.R`

The R working directory is probably incorrect.

Set the working directory to the top-level extracted Climate Menu folder and check:

```r
file.exists("RUN_CLIMATE_MENU.R")
```

### An analysis appears to take a long time

Climate Menu may need to discover and retrieve remote climate-model data before performing the analysis. Runtime depends on the selected dataset, period, model and analysis.

### Closing the browser does not stop Climate Menu

Return to RStudio and click the red **Stop** button or press **Esc**.

---

## 9. Reproducibility and spatial interpretation

Climate Menu records the analysis request and uses a targets-based backend to support reproducible climate-data processing.

Named Australian study areas use official ABS geography definitions where supported. Climate data retain their native climate-model grid resolution.

